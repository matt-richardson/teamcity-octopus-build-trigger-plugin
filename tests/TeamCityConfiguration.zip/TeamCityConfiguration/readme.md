teamcity configuration
